#!/bin/bash
cd /WS
PATH=/WS:$PATH
python /add.py 4 5
