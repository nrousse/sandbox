#!/bin/sh
#SBATCH --job-name=115-ws-sw_example 
#SBATCH --account=record 
#SBATCH --nodes=1 
#SBATCH --ntasks-per-node=1 
#SBATCH --partition=defq 
#SBATCH --time=4:00:00 
#SBATCH --mail-user=nathalie.rousse@inrae.fr 
#SBATCH --exclusive 
#SBATCH --mail-type=ALL 

module purge 
module load cv-standard 
module load intel/mpi/64/2017.1.132 
module load singularity/3.5 
echo $SLURM_JOB_ID > JOB_ID 

singularity exec --no-home --bind $PWD:/WS  /home/roussen/ws/simg/.sw_example-docker:latest.simg /WS/ws_command.sh

